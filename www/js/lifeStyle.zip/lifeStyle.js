var app = angular.module('lifstyleControllers', []);
  //fixed code controller slider

app.controller('SliderCtrl', function($scope, $state, $ionicSlideBoxDelegate, $timeout, $rootScope, $log,$ionicGesture, $ionicPopup) {
	$rootScope.images=["couple_holding_hands.jpg",
					  "couple_on_yatch.jpg",
					  "family_walking_on_beach.jpg",
					  "friends_drinking_cocktail.jpg",
					  "friends_enjoying_on_beach.jpg",
					  "girl_in_hat_in_water.jpg",
					  "grandparents_parent_and_children.jpg",
					  "parents_carrying_children_beach.jpg",
					  "relaxing.jpg",
					  "sunset_friends_party.jpg"];
	$scope.liked=[];
	$rootScope.endOfSlides=false;
	$rootScope.curImgIndex=0;
			  
	$scope.img = {
		cur: 'img/lifestyle/'+$rootScope.images[$rootScope.curImgIndex]
	}; 

	$scope.swipeLeft=function()
	{
		console.log($rootScope.curImgIndex);
		$rootScope.images.splice($rootScope.curImgIndex,1);
		console.log($rootScope.curImgIndex);
		if($rootScope.images[$rootScope.curImgIndex]==null||$rootScope.images[$rootScope.curImgIndex]==undefined||$rootScope.images[0]==undefined)
		{
			endSlide();
		}
		else{
			nextSlide(); 
		}
	}
	
	$scope.likeImg=function(name)
	{
		console.log($rootScope.curImgIndex);
		$scope.liked.push($rootScope.images[$rootScope.curImgIndex]);
		$rootScope.images.splice($rootScope.curImgIndex,1);
		if($rootScope.images[$rootScope.curImgIndex]==null||$rootScope.images[$rootScope.curImgIndex]==undefined)
		{
			endSlide();
		}
		else{
			nextSlide(); 
		}
				 
	}
		  
	$scope.dislikeImg=function()
	{
			 
		$rootScope.images.splice($rootScope.curImgIndex,1);
		if($rootScope.images[$rootScope.curImgIndex]==null||$rootScope.images[$rootScope.curImgIndex]==undefined)
		{
			endSlide();
		}
		else{
			nextSlide();
		}
	}
    
    $rootScope.showLikedImg=function()
	{
        $rootScope.images=[];
        endSlide();
	}
    
    
    
    
    endSlide=function()
	{
		console.log("liked:"+$scope.liked);
        console.log( $rootScope.images);

        $ionicPopup.show({
            title: 'Liked Images',
            subTitle: $scope.liked,
            buttons: [{
                text: 'Done'
            }]
        }).then(function(res) {});

        console.log("finished");
        $scope.img = {
            cur: 'img/lifestyle/end_of_image_list.jpg'
        };
        $rootScope.endOfSlides=true;
	}
    
    nextSlide=function()
	{
		$scope.img = {
            cur: 'img/lifestyle/'+$rootScope.images[$rootScope.curImgIndex]
        };
	}
    
});
